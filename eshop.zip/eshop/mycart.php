<?php/*
$id=$_GET['pid'];
if(isset($_COOKIE['cart']))
{
    $data=$_COOKIE['cart'].",".$id;
    setcookie("cart",$data,time()+36000);
}
else
{
    setcookie("cart",$id, time()+36000);
} 
header("location:mobiledesc.php?pid=$id");
*/?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mycart.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body>
     <div class="col-sm-12"><?php  include 'header.php'?></div>
    <div class="container-fluid">
         
           <div class="row" style="height:60px">
                   <div class="col-sm-12"><?php  include 'usermenu.php'?></div>
           </div>
           <div class="row" style="">
                   <div class="col-sm-12" style="background-color:white;">
                       <div class="row">
                           <div class="col-sm-12" style='margin-top:10px;height:100px;background-color: #ffd6cc'>
                               <?php
                                   echo "<h2 style='margin-top:20px;margin-left:100px'>";
                                   echo "My selected Products";
                                   echo "</h2>";
                                ?>
                           </div>
                       </div>
                               <?php
                               if(isset($_COOKIE['cart']))
                               {
                               if(isset($_GET['pid'])|isset($_GET['id']))
                               {
                               echo "<div class='container-fluid' style='margin-top:30px'>";       
                                    echo "<div class='row'>";
                                           echo "<div class='col-sm-12'>";    
                                                  echo "<table class='table table-striped' style='margin-left:50px;'>";
                                                       echo "<tr>";
                                                              echo "<th>Product Id</th><th>Product Name</th><th>Product Image</th><th>Product Price</th><th>Remove</th>";
                                                        echo "</tr>";
                                                        
                                                        
                                                                 $pro_id = $_COOKIE['cart'];   
                                                                 $pro_id = explode(',', $pro_id);
                                                                 $pro_id=array_unique($pro_id);
                                                                 $link=mysql_connect("localhost","root","");
                                                                 mysql_select_db("eshop");
                                                                 $a=0;
                                                                 $i=0;
                                                                 $order="";
                                                                  $p=0;
                                                                 foreach ($pro_id as $val) 
                                                                  {
                                                                        $result=mysql_query("select * from product_master where pid='$val'");
                                                                        $r=mysql_fetch_array($result);
                                                                        $order[$p]=$val;
                                                                        $p++;
                                                                         
                                               
                                                                                echo "<tr>";
                                                                                          echo "<th>$r[0]</th><th>$r[1]</th><th><img src='$r[4]' width='50px' height='60px'></th><th>&#8377;$r[3]</th>";
                                                                                          echo "<th><a href='remove.php?pid=$r[0]'><input type='button' style='background-color:#ABEBC6;border-radius:5px' name='n' value='Remove product'></a></th>";
                                                                                echo "</tr>";
                                                                        $a=$a+$r[3];
                                                                        $i++;
                                                                   }
                                                                    
                                                              echo "</tr>";                
                                                         echo "</table>";
                                                    echo "</div>";
                                                echo "</div>";
                                    echo "</div>";  
                                    setcookie('num',$i,time()+360000);
                                     echo "<div class='container' style='margin-top:30px'>";       
                                    echo "<div class='row'>";
                                           echo "<div class='col-sm-4'>";    
                                                  
                                                    echo "</div>";
                                           echo "<div class='col-sm-4'>";    
                                                                  echo "<table class='table table-striped' >";
                                                                     echo "<tr>";
                                                                           echo "<th>Total Item</th><th>$i</th>";
                                                                     echo "</tr>";
                                                                     echo "<tr>";
                                                                           echo "<th>Price($i items)</th><th>&#8377;$a</th>";
                                                                     echo "</tr>";
                                                                     echo "<tr>";
                                                                           echo "<th>Delivery Fee</th><th>&#8377;45</th>";
                                                                     echo "</tr>";
                                                                     $a=45+$a;
                                                                     echo "<tr>";
                                                                           echo "<th>Total Amount</th><th>&#8377;$a</th>";
                                                                     echo "</tr>";
                                                                     echo "<tr>";
                                                                     $na="";
                                                                    
                                                                    if(isset($_SESSION['email']))
                                                                           $na=$_SESSION['email'];
                                                                           $order=implode(",",$order);
                                                                          $order=strval($order);
                                                                           echo "<th colspan=2><a href='placeorder.php?list=$order & user=$na'><input type='button' name='' style='margin-left:56px;padding-left:60px;padding-right:60px;background-color:#FAD7A0 ' value='Place Order'></a></th>";
                                                                     echo "</tr>";
                                                                  echo "</table>";
                                                    echo "</div>";
                                          echo "<div class='col-sm-4'>";          
                                                    echo "</div>";
                                                echo "</div>";
                                    echo "</div>"; 
                               }
                               else{
                                   echo "<div class='row' style='background-color:#ccf2ff;height:70px;margin-top:15px'>";
                                          echo "<div class='col-sm-12'>";
                                                echo "<h4 align='center' style='margin-top:10px'>Your Cart is Empty Now...!!</h4>";
                                          echo "</div>";
                                   echo "</div>";
                               }
                               }
                              else {
                                  echo"<h3>Empty</h3>";
     
                                     }
                                                    ?>
                    
                              
                               
                           </div>
                       </div>
                   </div>
           </div>
         
           </div>
    </div>
    <div class='col-sm-12'><?php  include 'footer.php'; ?></div>
</body>
</html>  
    </body>
</html>

