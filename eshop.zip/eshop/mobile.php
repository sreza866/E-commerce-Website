<!DOCTYPE html>
<?php
  session_start();
   if(!isset($_SESSION['name']))
   {
       header("location:login.php");
   }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eshop.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body>
  <?php include 'header.php';?>
    <?php  include 'usermenu.php'?>;
    <div class="container">
    <?php   
        include 'db.php';
        $result=mysql_query("select * from product_master where ptype='Mobile'");
          if(mysql_affected_rows()>0)
          {

          $x=1;
          while($r=mysql_fetch_assoc($result))
          {
             if($x==1)
              echo"<div class='row'>";
                  echo"<div class='col-sm-3' style='border-style:solid;border-spacing:1px;margin-left:50px;margin-top:20px'>";
              echo"<div class='row'>";
                      echo"<div class='col-sm-12'><a href='mobiledesc.php?pid=$r[pid]'><marquee behavior='alternate'><img src='$r[pimage]' style='width:150px;height:300px'/></marquee></a></div>";
                  echo"</div>";
              echo "<div class='row'>";
                     echo"<div class='col-sm-6'>Name</div> <div class='col-sm-6'>$r[pname]</div>";
               echo"</div>";
                echo"<div class='row'>"; 
                     echo"<div class='col-sm-6'>Price</div><div class='col-sm-6'>$r[pprice]</div>";
                echo"</div>";
               echo"</div>";
                  $x++;
              if($x==4)
              {
              echo"</div>";
              $x=1;
              }
                 
          }
        }
        else
        {
        echo"<h2>Currently no products are available</h2>";
        }
       
        ?> 
    </div>
    
     <?php 
     include 'footer.php';
     ?>

      
</body>
</html>
