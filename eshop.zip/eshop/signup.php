<?php
  include 'header.php';
 
    $msg="";
  if(isset($_POST['Register']))
  {
      
      $name=$_POST['txt_name'];
      $email=$_POST['txt_email'];
      $password=$_POST['txt_pwd'];
      $gender=$_POST['txt_gen'];
      $dob=$_POST['txt_dob'];
      $phone=$_POST['txt_phone'];
      
     
     
     $link=mysql_connect("localhost","root","");
      mysql_select_db("eshop");
      $qry="insert into  signup values('$name','$email','$password','$gender','$dob','$phone','client')";
      mysql_query($qry);
      if(mysql_affected_rows()>0)
      {
           $msg="<h5><font color='green'>Registered Successfully!</font></h5>";
      }
      else {
               $msg="<h5><font color='red'>Error in Registering??</font></h5>";
           }
           mysql_close($link);
      } 


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Signup</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div style="background-color:peachpuff;width:100%;height: 100%">
        
    <form method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-5" style="margin-left: 100px;height:600px;margin-top:60px;padding-left:40px;padding-left:40px;padding-bottom:40;background-color:orangered">
         <marquee><h3><font color='yellow'> Signup Here </font></h3></marquee>
        <table
                <tr>
                    <td> <label style='margin-top:100px'>Enter Your Name</label></td>
                    <td> <input type="text" style='margin-top:100px;margin-left:50px;width:300px' placeholder="Name" name="txt_name" value=""/></td>
                </tr>
                <tr>
                    <td> <label style='margin-top:20px'>Email Id</label></td>
                    <td> <input type="email" style='margin-top:20px;margin-left:50px;width:300px' placeholder="abc@example.com"name="txt_email" value=""/></td>
                </tr>
                <tr>
                    <td><label style='margin-top:20px'>Password</label></td>
                    <td> <input type="password" style='margin-top:20px;margin-left:50px;width:300px' name="txt_pwd" value=""/></td>
                </tr>
                <tr>
                    <td> <label style='margin-top:20px'>Gender</label></td>
                    <td><input type="text"  style='margin-top:20px;margin-left:50px;width:300px' name="txt_gen" value=""/></td>
                    
                </tr>
                <tr>
                    <td> <label style='margin-top:20px'>Date of birth</label></td>
                    <td><input type="text" style='margin-top:20px;margin-left:50px;width:300px' placeholder="DD-MM-YYYY" name="txt_dob" value=""/></td>  
                </tr>
                <tr>
                    <td> <label style='margin-top:20px'>phone</label></td>
                    <td><input type="number" style='margin-top:20px;margin-left:50px;width:300px' placeholder="123456789" name="txt_phone" value=""/></td> 
                </tr>
                </table>
            <div style="text-align:right"> <input type='submit' name='Register' value="Register" style='margin-top: 100px;background-color:green;margin-right:250px'></div>
              <?php
                                  if(isset($_POST['Register']))
                                   {
                                       echo "<br><br>";
                                       echo $msg;
                                   }
                                   ?> 
        </div>
    </form>
    <div class="col-sm-3"></div>
       
    </div>
         <?php include 'footer.php';?>
    </div>
    
</body>
</html>
  
