    
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Bootstrap 4 Dropdowns within a Navbar</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<style>
	.bs-example{
    	margin: 0px;
    }
</style>
</head>
<body>
<div class="bs-example">
    <nav class="navbar navbar-expand-md navbar-light bg-light container-fluid">
        <div id="navbarCollapse" class="row collapse navbar-collapse" style="font-size:large;background-color:blanchedalmond;">
            <div class="col-sm-2 nav navbar-nav" >
                <li class="nav-item" >
                    <a href="Home.php"style='color:blue' class="nav-link">Home</a>
                </li>
                </div>
                <div class="col-sm-2 nav navbar-nav">
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" style='color:blue'>Products</a>
                    <div class="dropdown-menu">
                        <a href="mobile.php" class="dropdown-item">Mobile</a>
                        <a href="#" class="dropdown-item">cloths</a>
                        <a href="#" class="dropdown-item">TV</a>
                        <a href="#"class="dropdown-item">Refrigerator</a>
                        <a href="#"class="dropdown-item">Electronics Appliances</a>
                        <a href="#"class="dropdown-item">Toys</a>
                      
                    </div>
                </li>
            </div>
            <div class="col-sm-2 nav navbar-nav">
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"style='color:blue'>Login</a>
                    <div class="dropdown-menu">
                       <?php 
                       
                        session_start();
                        if(isset($_SESSION['name']))
                        {
                        echo"<a href='login.php' class='dropdown-item'>My Account</a>";
                       echo" <a href='signup.php' class='dropdown-item'>My Orders</a>";
                        }
                     else
                       {
                        echo "<a href='login.php' class='dropdown-item'>Signin</a>";
                       echo " <a href='signup.php' class='dropdown-item'>Signup</a>";
                       }
                               ?>
                    </div>
                </li>
        </div>
        <div class="col-sm-2 nav navbar-nav" >
                <li class="nav-item" >
                    <a href="About.php" class="nav-link"style='color:blue'>About Us</a>
                </li>
        </div>
        <div class="col-sm-2 nav navbar-nav">
                <li class="nav-item">
                    <a href="contact.php" class="nav-link" style='color:blue'>Contact Us</a>
                </li>
        </div>
        <div class="col-sm-2 nav navbar-nav">
            <li class="nav-item">
                <a href="help.php" class="nav-link" style='color:blue'>Help</a>
            </li>
    </div>
             <div class="col-sm-2 nav navbar-nav" >
    </div>
        </div>
    </nav>
</div>
