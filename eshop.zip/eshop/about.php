<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title></title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
    <?php 
    include 'header.php';
    include 'usermenu.php';   
    ?>
    
    <div class="container-fluid" style="background-color:blanchedalmond">
        
        <p><h3>eShop is an Indian e-commerce company based in Bangalore, Karnataka, India. It was founded by Subhan Reza in 2020.<br>
                The company initially focused on book sales, before expanding into other product categories such as consumer electronics,<br> fashion, home essentials & groceries,
and lifestyle products.
The service competes primarily with Amazon's Indian subsidiary, and the domestic rival Snapdeal.<br>
    As of March 2017, eShop held a 39.5% market share of India's e-commerce industry.<br> eShop is significantly dominant in the sale of 
        apparel (a position that was bolstered by its acquisition of Myntra),<br> and was described as being "neck and neck" with Amazon in 
            the sale of electronics and mobile phones.<br> Flipkart also owns PhonePe, a mobile payments service 
                based on the Unified Payments Interface (UPI).</h3></p></div>
    <?php include 'footer.php';?>
</body>
</html>
