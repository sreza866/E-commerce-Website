<?php
$id=$_GET['pid'];
if(isset($_COOKIE['cart']))
{
    $data=$_COOKIE['cart'].",".$id;
    setcookie("cart",$data,time()+3600*24*15);
}
else
{
    setcookie("cart",$id, time()+3600*24*15);
} 
header("location:mobiledesc.php?pid=$id");
?>

