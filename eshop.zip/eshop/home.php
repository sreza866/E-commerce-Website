﻿<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title></title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript">
    function getproduct()
  {
      data=document.getElementById("search").value;
      obj=new XMLHttpRequest();
      obj.open("GET","getproduct.php?id="+data,true);
      obj.send();
      obj.onreadystatechange=function(){
          if(obj.readyState==4 && obj.status==200)
          {
             document.getElementById("t1").hidden=true;
             document.getElementById("t2").innerHTML=obj.responseText;
          }
          
      }
  }
</script>
</head>
<body>
<div class="container-fluid">
 <div class="row">
      <div class="col-sm-12"><?php include 'header.php' ?></div>
     
    <div class="col-sm-12"><?php include 'usermenu.php' ?></div>
   
 </div>

   

    <div id="t1">                           
 <div class="row">
     <div class="col-sm-12">
         
         <?php
                          $x=1;
                          $p=1;
                         
                          if(isset($_COOKIE['rec']))
                          {
                            $pro_id = $_COOKIE['rec'];   
                            $pro_id = explode(',', $pro_id);
                            $pro_id=array_unique($pro_id);
                            $link=mysql_connect("localhost","root","");
                            mysql_select_db("eshop");
                            
                            
                            $pro_id= array_reverse($pro_id);
                             array_shift($pro_id);
                             
                            foreach($pro_id as $val)
                            {                                 
                                 $result=mysql_query("select * from product_master where pid=$val");
                                  $r=mysql_fetch_array($result);
                                 
                            if($p<7)
                            {
                            
             if($x==1)
              echo"<div class='row'>";
                  echo"<div class='col-sm-3' style='border-style:solid;border-spacing:1px;margin-left:50px;margin-top:20px'>";
              echo"<div class='row'>";
                      echo"<div class='col-sm-12'><a href='mobiledesc.php?pid=$r[pid]'><marquee behavior='alternate'><img src='$r[pimage]' style='width:150px;height:300px'/></marquee></a></div>";
                  echo"</div>";
              echo "<div class='row'>";
                     echo"<div class='col-sm-6'>Name</div> <div class='col-sm-6'>$r[pname]</div>";
               echo"</div>";
                echo"<div class='row'>"; 
                     echo"<div class='col-sm-6'>Price</div><div class='col-sm-6'>$r[pprice]</div>";
                echo"</div>";
               echo"</div>";
                  $x++;
              if($x==4)
              {
              echo"</div>";
              $x=1;
              }
              $p++;
                 
          }                   
                            }
                          
                          if($x!=1)
                              echo "</div>";
                          }
                          
                           ?>
     </div>

 
 </div>
    </div>
    <div id="t2"></div>
 <div class="row">
   <div class="col-sm-12"><?php include 'footer.php' ?></div>
 </div>
<div>
   

</body>
</html>