<?php
   if(isset($_POST['sub']))
   {
       $name=$_POST['txt_name'];
       $email=$_POST['txt_email'];
       $phone=$_POST['txt_phone'];
       $query=$_POST['txt_query'];
       include 'db.php';
       $qry="insert into contact values('$name','$email',$phone,'$query')";
          mysql_query($qry);
      if(mysql_affected_rows()>0)
      {
           $msg="<h5><font color='green'>submitted successfully...!!!!!!!!!</font></h5>";
      }
      else {
               $msg="<h5><font color='red'>Not Submitted..??</font></h5>";
           }
           mysql_close($link);
      }

       
   
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eshop.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body>
    <?php include 'header.php';?>
    <?php include'usermenu.php';?>

        <div class="container" style="width:600px;height: 700px;background-color:chocolate">
            <form method='post' enctype="multipart/form-data">
            <p><b>If you want to know more about eShop services or have a query please submit your query here ,Our eShop customer will reach you soon.For any further help call us on <font color=blue>1800-208-9898</font></b></p>
        <table>
         
            <tr>
                <td><label style="margin-top:50px">Name</label></td>
                <td><input type ='text' style="margin-top:50px;height:40px;width:400px" name='txt_name' value=""/></td>
            </tr>
            <tr>
                <td><label style="margin-top:50px">Email ID</label></td>
                <td><input type='email' style="margin-top:50px;height:40px;width:400px" name='txt_email' value=""/></td>
            </tr>
            <tr>
                <td><label style="margin-top:50px">Phone</label></td>
                <td><input type='text'style="margin-top:50px;height:40px;width:400px" name='txt_phone' value=""/></td>
            </tr>
            <tr>
                <td><label style="margin-top:50px">Write Your Query</label>
                <td><textarea style="margin-top:50px;height:150px;width:400px" name="txt_query"></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" style=" width:110px;height:30px;margin-left:300px;margin-top:50px;background-color:lightgreen;font-weight:bold;border-top:2px solid #4f6267;border-bottom:2px solid #a3ceda;border-left:2px solid  #a3ceda;border-right:2px solid #4f6267" name="sub" value="submit"/></td>
            </tr>
        </table>
            
       
    </form>
     </div>
    <?php
    include 'footer.php';
    ?>
    
</body>
</html>
