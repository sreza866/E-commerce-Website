﻿<div class="row" style="background-color:orange">
    <div class="col-sm-12 text-center"><h3>
           
            © Copyright reserved by eShop</h3>
    </div>
  

</div>