-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 13, 2020 at 12:59 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(30) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `phone` int(10) NOT NULL,
  `query` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `emailid`, `phone`, `query`) VALUES
('Abc', 'barun@gmail.com', 2147483647, 'yfyfy');

-- --------------------------------------------------------

--
-- Table structure for table `place_order`
--

CREATE TABLE IF NOT EXISTS `place_order` (
  `name` varchar(30) NOT NULL,
  `phone` int(11) NOT NULL,
  `houseno` varchar(20) NOT NULL,
  `street` varchar(30) NOT NULL,
  `locality` varchar(30) NOT NULL,
  `pincode` int(10) NOT NULL,
  `state` varchar(30) NOT NULL,
  `user` varchar(30) DEFAULT NULL,
  `orderid` varchar(100) DEFAULT NULL,
  `productid` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `place_order`
--

INSERT INTO `place_order` (`name`, `phone`, `houseno`, `street`, `locality`, `pincode`, `state`, `user`, `orderid`, `productid`) VALUES
('Ashish Kaushal', 2147483647, '1', 'RAHAM KHAN,DEORHI', 'dbg', 846004, 'Bihar', 'ashish@gmail.com', '5f0b51deba55e', '1000001,1000002 ');

-- --------------------------------------------------------

--
-- Table structure for table `product_desc`
--

CREATE TABLE IF NOT EXISTS `product_desc` (
  `pid` int(11) NOT NULL,
  `model_no` varchar(30) NOT NULL,
  `brand` varchar(30) NOT NULL,
  `processor` varchar(20) NOT NULL,
  `ram` varchar(10) NOT NULL,
  `screen_size` varchar(10) NOT NULL,
  `storage` varchar(20) NOT NULL,
  `front_camera` varchar(10) NOT NULL,
  `rare_camera` varchar(10) NOT NULL,
  `battery_cap` varchar(15) NOT NULL,
  `connectivity` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_desc`
--

INSERT INTO `product_desc` (`pid`, `model_no`, `brand`, `processor`, `ram`, `screen_size`, `storage`, `front_camera`, `rare_camera`, `battery_cap`, `connectivity`) VALUES
(1000001, '5 Pro', 'Realme', '2.3Ghz octa core', '6GB', '6.30', '64GB', '16-megapix', '48-megapix', '4035 mAh', '4G/3G/GSM'),
(1000002, '5 Pro', 'Redmi', '2.3Ghz octa core', '6GB', '6.30', '64GB', '16-megapix', '48-megapix', '4000 mAh', '4G/3G/GSM'),
(1000003, '7T pro', 'Oneplus', '2.96Ghz octa core', '8GB', '6.67', '256GB', '16-megapix', '48MP+8MP+1', '4085 mAh', '4G/3G/GSM');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE IF NOT EXISTS `product_master` (
  `pid` int(11) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `ptype` varchar(30) NOT NULL,
  `pprice` int(11) NOT NULL,
  `pimage` varchar(100) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`pid`, `pname`, `ptype`, `pprice`, `pimage`) VALUES
(1000001, 'Realme 5pro', 'Mobile', 14999, 'photo/realme-5-pro-.jpeg'),
(1000002, 'Redmi note7', 'Mobile', 13999, 'photo/realme-5-pro-.jpeg'),
(1000003, 'Moto G8 power', 'Mobile', 9999, 'photo/motorola-g8.jpeg'),
(1000004, 'Vivo S1 pro', 'Mobile', 20600, 'photo/vivoS1pro.jpg'),
(1000005, 'POCO F1', 'Mobile', 16999, 'photo/pocoF!.jpg'),
(1000007, 'Oneplus 7T pro', 'Mobile', 48000, 'photo/oneplus7Tpro.jpg'),
(1000008, 'Samsung Galaxy A10', 'Mobile', 109999, 'photo/samsung-galaxy-a10.jpeg'),
(1000009, ' Iphone 11pro', 'Mobile', 68000, 'photo/iphone11.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `name` varchar(30) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `dob` varchar(12) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`name`, `emailid`, `password`, `gender`, `dob`, `phone`, `role`) VALUES
('Amir Reza', 'amirreza2a141@gmail.com', 'amir123', 'male', '27-10-1998', 9065154267, 'admin'),
('Ashish Kaushal', 'ashish@gmail.com', 'ashish123', 'male', '16-01-1999', 6207194862, 'client'),
('Barun Sinha', 'barun@gmail.com', 'barun123', 'male', '24-09-1999', 6207194862, 'client'),
('Shazia Sadique', 'shazia@gmail.com', 'shazia123', 'female', '11-11-1999', 7766012567, 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
