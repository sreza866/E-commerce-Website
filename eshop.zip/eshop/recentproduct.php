<?php
$id=$_GET['pid'];
if(isset($_COOKIE['cart']))
{
    $data=$_COOKIE['cart'].",".$id;
    setcookie("cart",$data,time()+3);
}
else
{
    setcookie("cart",$id, time()+3);
} 
header("location:mobiledesc.php?pid=$id");
?>
