<?php
                           $da=$_GET['id'];
                           $link=mysql_connect("localhost","root","");
                            mysql_select_db("eshop");
                            $result=mysql_query("select * from product_master where pname like '$da%'");
                            if(mysql_affected_rows()>0)
                            {
                             $x=1;
                             while($r=mysql_fetch_assoc($result))
                             {
                              if($x==1)
                                  echo "<div class='row'>";
                                        echo "<div class='col-sm-3' style='border-style:solid;margin-left:100px;margin-top:25px'>";
                                                echo "<div class='row' style='margin-bottom:5px;margin-top:5px'>";
                                                         echo "<div class='col-sm-12'><a href='view.php?pid=$r[pid]'><marquee behaviour='alternate'><img src=$r[pimage] width='150px' height='250px'></marquee></a><a href='' style='margin-left:40px;'><input type='button' style='background-color:yellow;padding-left:25px;padding-right:25px' name='num' value='BUY NOW'></a>";
                                                          echo "</div>";
                                                         echo "</div>";
                                                echo "<div class='row' style='background-color:lightcoral'>";
                                                         echo "<div class='col-sm-4'>Name</div><div class='col-sm-8'>$r[pname]</div>";
                                                          echo "<div class='col-sm-4'>Price</div><div class='col-sm-8'>&#8377;$r[pprice]</div>";
                                                         echo "</div>";         
                                                         
                                        echo "</div>";
                               $x=$x+1;         
                              if($x==4)
                              {
                               echo "</div>";
                               $x=1;
                              }
                                 
                             }
                            if($x!=1)
                                echo "</div>";
                            }
                            else
                            {
                                echo "No product Found...!!";
                            }
                        
                           ?>