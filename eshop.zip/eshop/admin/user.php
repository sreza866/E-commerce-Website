<?php
session_start();
if(!isset($_SESSION['name']))
{
    header("location:alogin.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mycart.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<style>
    .btn1{
        width:100%;
        padding-left:20px;
        padding-right: 20px;
        border-radius:5px; 
        background-color: lightgreen;
    }
</style>
</head>
<body>
   
           <div class="row" style="background-color:grey;height:100px;padding-left:20px">
        <div class="col-sm-12">
            
     
       <?php
       
       include 'aheader.php';
       ?>
               </div>
    </div>
           <div class="row" style="height:60px">
                   <div class="col-sm-12"><?php  include 'menu.php'?></div>
           </div>
           <div class="row" style="">
                   <div class="col-sm-12" style="background-color:white;">
                       <div class="row">
                          
                       </div>
                       <div style='margin-top:20px'>
                           <?php
                                 $link=mysql_connect("localhost","root","");
                                 mysql_select_db("eshop");
                                 $result=mysql_query("select * from signup");
                                 if(mysql_affected_rows()>0)
                                 {
                                     echo "<table class='table table-striped'>";
                                     echo "<tr>";
                                     echo "<th>NAME</th><th>EMAIL ID</th><th>PASSWORD</th><th>GENDER</th><th>Date of Birth</th><th>Mobile Number</th><th>DELETE USER</th>";
                                     echo "</tr>";
                                     while($r=mysql_fetch_array($result))
                                     {
                                         echo "<tr>";
                                         echo "<td>$r[0]</td>";
                                         echo "<td>$r[1]</td>";
                                         echo "<td>$r[2]</td>";
                                         echo "<td>$r[3]</td>";
                                         echo "<td>$r[4]</td>";
                                         echo "<td>$r[5]</td>";
                                         echo "<td><a href='delete_user.php?pid=$r[1]'><input type='button' class='btn1' value='Delete'/></a></td>";
                                         echo "</tr>";
                                     }
                                     echo "</table>";
                                 }
                           ?>
                       </div>
                   </div>
           </div>
          
                  <?php include '../footer.php';?>
           
    
</body>
</html>
