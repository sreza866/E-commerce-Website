﻿<div class="row" style="font-size:large;height:60px;background-color:lightgreen">
    <div class="col-sm-2"> <img src="../eshop.jpg" style="height:60px;width:90px"/></div>
    <div class="col-sm-6" style="padding-top: 10px"> <label>search</label><input type='text' name='bar' style='margin-left: 10px;border-radius: 5px' size='40' placeholder="search for products" value=''/></div>
 <div class="col-sm-1" style="padding-top: 10px"> <a href="user.php">User</a></div>
                
 <div class="col-sm-1" style="padding-top: 10px"> <a href="#">More</a></div>
  
 <div class='col-sm-1' style='padding-top: 10px'><a href='alogin.php'>Login</a></div>
 <div class='col-sm-1' style='padding-top: 10px'><a href='alogout.php'>Logout</a></div>

</div>
