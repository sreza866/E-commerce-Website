<?php
session_start();
if(!isset($_SESSION['name']))
{
    header("location:alogin.php");
}
?>
<?php
    $msg="";
  if(isset($_POST['sub']))
  {
      
      $id=$_POST['txt_pid'];
      $model=$_POST['txt_model'];
      $brand=$_POST['txt_brand'];
      $processor=$_POST['txt_pro'];
      $ram=$_POST['txt_ram'];
      $screen=$_POST['txt_screen'];
      $storage=$_POST['txt_stor'];
      $front=$_POST['txt_front'];
      $rare=$_POST['txt_rare'];
      $battery=$_POST['txt_batt'];
      $network=$_POST['txt_net'];
     
     $link=mysql_connect("localhost","root","");
      mysql_select_db("eshop");
      $qry="insert into  product_desc values('$id','$model','$brand','$processor','$ram','$screen','$storage','$front','$rare','$battery','$network')";
      mysql_query($qry);
      if(mysql_affected_rows()>0)
      {
           $msg="<h5><font color='green'>Product decription Added...!!!!!!!!!</font></h5>";
      }
      else {
               $msg="<h5><font color='red'>Error in Adding Product decription..??</font></h5>";
           }
           mysql_close($link);
      } 


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eshop.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container-fluid">
           <div class="row" style="height:60px">
                   <div class="col-sm-12"></div>
           </div>
         
           <div class="row" style="">
                   <div class='col-sm-12' style='background-color:lightcoral'>
                       <div><h2 align='center'><font color='blue'> <u>For Adding Product Description</u></font></h2></div>
                       <div class='row'>
                           <div class='col-sm-4'></div>
                           <div class='col-sm-4' style='margin-left: 60px'>
                               <form method="post" enctype="multipart/form-data">
                                   <table>
                                         <tr>
                                   <div class='form-inline'>
                                     
                                           <td> <label align="center">Product Id</label><br></td>
                                           <td><input type='text' name='txt_pid' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                     
                                   </div>
                                   </tr>
                                         <tr>
                                   <div class='form-inline'> 
                                       
                                       <td> <label>Model No</label><br></td>
                                       <td><input type='text' name='txt_model' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                       
                                   </div>
                                   </tr>
                                   <tr>
                                       <div class='form-inline'>
                                       <td><label>Brand</label><br></td>
                                       <td> <input type='text' name='txt_brand' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
     
                                   </div>
                                   </td>
                                   <tr>
                                   <div class='form-inline'>
                                       <td> <label>Processor</label><br></td>
                                       <td><input type='text' name='txt_pro' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                   <div class='form-inline'>
                                       <td> <label>RAM</label></td>
                                       <td><input type='text' name='txt_ram' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                     <div class='form-inline'>
                                         <td><label>Screen size</label></td>
                                         <td><input type='text' name='txt_screen' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                     <div class='form-inline'>
                                         <td> <label>Storage</label></td>
                                         <td> <input type='text' name='txt_stor' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                     <div class='form-inline'>
                                         <td> <label>front camera</label></td>
                                         <td> <input type='text' name='txt_front' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                     <div class='form-inline'>
                                         <td> <label>Rare camera</label></td>
                                         <td><input type='text' name='txt_rare' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                     <div class='form-inline'>
                                         <td><label>Battery </label></td>
                                         <td> <input type='text' name='txt_batt' value="" style='padding-left:100px;padding-right: 100px;padding-bottom:15px;margin-left:5px' class="form-control"></td>
                                     </div>
                                   </tr>
                                   <tr>
                                     <div class='form-inline'>
                                         <td> <label>Network </label></td>
                                         <td><input type='text' name='txt_net' value="" style='padding-left:100px;padding-right: 100px;padding-bottom: 15px;margin-left:5px' class="form-control"></td>
                                   </div>
                                   </tr>
                                   <tr>
                                       <td></td>
                                       <td> <input type="submit" style="padding-left:50px ;padding-right:50px;margin-left: 100px;background-color: yellow" name="sub" value="Add Product description"></td>
                                   </tr>
                                   </table>
                                   <?php
                                  if(isset($_POST['sub']))
                                   {
                                       echo "<br><br>";
                                       echo $msg;
                                   }
                                   ?>  
                                  
                               </form>
                           </div>
                           <div class='col-sm-4'></div>
                       </div>
                   </div>
           </div>
    </body>
    </html>
