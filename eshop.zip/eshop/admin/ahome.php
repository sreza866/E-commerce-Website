<?php
session_start();
if(!isset($_SESSION['name']))
{
    header("location:alogin.php");
}
?>
﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title></title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
 

     
       <?php
       
       include 'aheader.php';
       ?>
               </div>
    </div>
      <div class="row">
     
   <div class="col-sm-12"><?php include 'menu.php' ?></div>
      </div>
     <div class="col-sm-12"> <strong style="font-size:large;padding-top:50px;color: brown">eShop admin panel:</strong></div>
    <div class='col-sm-12' style="margin-top: 30px">
        <h2><font color='lime'><?php

 
   if(isset($_SESSION['name']))
   {
      echo "Welcome ".$_SESSION['name'];
   }
  
?>
                    </font></h2>
        
            
    </div>
    
    <div class="container">
    <?php   
        include '../db.php';
        $result=mysql_query("select * from product_master where ptype='Mobile'");
          if(mysql_affected_rows()>0)
          {

          $x=1;
          while($r=mysql_fetch_assoc($result))
          {
             if($x==1)
              echo"<div class='row'>";
                  echo"<div class='col-sm-3' style='border-style:solid;border-spacing:1px;margin-left:50px;margin-top:20px'>";
              echo"<div class='row'>";
                      echo"<div class='col-sm-12'><a href='mobiledesc.php?pid=../$r[pid]'><marquee behavior='alternate'><img src='../$r[pimage]' style='width:150px;height:300px'/></marquee></a></div>";
                  echo"</div>";
              echo "<div class='row'>";
                     echo"<div class='col-sm-6'>Name</div> <div class='col-sm-6'>$r[pname]</div>";
               echo"</div>";
                echo"<div class='row'>"; 
                     echo"<div class='col-sm-6'>Price</div><div class='col-sm-6'>$r[pprice]</div>";
                echo"</div>";
               echo"</div>";
                  $x++;
              if($x==4)
              {
              echo"</div>";
              $x=1;
              }
                 
          }
        }
        else
        {
        echo"<h2>Currently no products are available</h2>";
        }
       
        ?> 
    </div>
   

<?php include '../footer.php';?>


</body>
</html>

