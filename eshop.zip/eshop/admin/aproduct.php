<?php
session_start();
if(!isset($_SESSION['name']))
{
    header("location:alogin.php");
}
?>
<?php
    $msg="";
  if(isset($_POST['sub']))
  {
      $id=$_POST['txt_pid'];
      $name=$_POST['txt_name'];
      $type=$_POST['txt_type'];
      $price=$_POST['txt_price'];
      $src=$_FILES['txt_image']['tmp_name'];
  
      $des=$_SERVER["DOCUMENT_ROOT"]."eshop/photo/".$_FILES['txt_image']['name'];
      move_uploaded_file($src,$des);
      $path='photo/'.$_FILES['txt_image']['name'];
      include '../db.php';
      $qry="insert into product_master values('$id','$name','$type',$price,'$path')";
      mysql_query($qry);
      if(mysql_affected_rows()>0)
      {
           $msg="<h5><font color='green'>Product Added...!!!!!!!!!</font></h5>";
      }
      else {
               $msg="<h5><font color='red'>Error in Adding Product..??</font></h5>";
           }
           mysql_close($link);
      }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eshop.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container-fluid">
           <div class="row" style="height:60px">
                   <div class="col-sm-12"><?php include 'aheader.php';?></div>
                   
                  
           </div>
           <div class="row" style="height:60px">
                   <div class="col-sm-12"></div>
           </div>
           <div class="row" style="">
                   <div class="col-sm-12" style="background-color:lightcoral">
                       <div><h2 align='center'><font color='blue'> <u>For Adding Product</u></font></h2></div>
                       <div class='row'>
                           <div class='col-sm-4'></div>
                           <div class='col-sm-4' style="margin-left: 60px">
                               <form method="post" enctype="multipart/form-data">
                                   <div class='form-group'>
                                       <label align="center">Product Id</label><br>
                                       <input type='text' name='txt_pid' value="" style='padding-left:100px;padding-right: 100px;padding-bottom: 15px' class="from-control">
                                   </div>
                                   <div class='form-group'>
                                       <label>Product Name</label><br>
                                       <input type='text' name='txt_name' value="" style='padding-left:100px;padding-right: 100px;padding-bottom: 15px' class="from-control">
                                   </div>
                                   <div class='form-group'>
                                       <label>Product Type</label><br>
                                       <input type='text' name='txt_type' value="" style='padding-left:100px;padding-right: 100px;padding-bottom: 15px' class="from-control">
                                   </div>
                                   <div class='form-group'>
                                       <label>Product Price</label><br>
                                       <input type='text' name='txt_price' value="" style='padding-left:100px;padding-right: 100px;padding-bottom: 15px' class="from-control">
                                   </div>
                                   <div class='form-group'>
                                       <label>Product Image</label>
                                       <input type='file' name='txt_image' value="" style='padding-left:100px;padding-right: 100px;padding-bottom: 15px' class="from-control">
                                   </div>
                                 
                                   <input type='submit' style='padding-left:50px ;padding-right:50px;margin-left: 100px;background-color: yellow' name='sub' value="Add Product">
                                   <?php
                                   if(isset($_POST['sub']))
                                   {
                                       echo "<br><br>";
                                       echo $msg;
                                   }
                                   ?>
                               </form>
                           </div>
                           <div class='col-sm-4'></div>
                       </div>
                   </div>
           </div>
           
     
</body>
</html>

