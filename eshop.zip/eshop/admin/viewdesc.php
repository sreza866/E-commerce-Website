   <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Description</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body> 
    <?php include 'aheader.php';
           include 'menu.php';
           ?>
      <div class="container">
          <div class="row">
              <div class="col-sm-12">
    <?php   
        include_once'../db.php';
        $result=mysql_query("select * from product_master where pid=$_GET[pid]");
        $r=mysql_fetch_assoc($result);
              echo"<div class='row'>";
                  echo"<div class='col-sm-5'>";
                    echo"<img src='../$r[pimage]' style='margin-top:20px;width:150px;height:300px'/>";
                  echo"</div>";
                  echo"<div class='col-sm-6'style='margin-top:20px'>";
                     echo"<div class='row' style='padding-top:20px' ><div class='col-sm-4'>Name</div> <div class='col-sm-4'><b>$r[pname]</b></div></div>";
                     echo"<div class='row' style='padding-top:20px'><div class='col-sm-4'>Price</div> <div class='col-sm-4'><b>$r[pprice]<b></div></div>";
                     ?>
              
     <?php
        $result1=mysql_query("select * from product_desc where pid=$_GET[pid]");
        $r1=mysql_fetch_array($result1);
           echo"<table class='table table-stripped width=100%'>";
                             echo"<tr>";
                                 echo "<td>Model-No</td><td>$r1[1]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                  echo"<td>Brand</td><td>$r1[2]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                 echo"<td>Processor</td><td>$r1[3]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                   echo"<td>RAM</td><td>$r1[4]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                echo"<td>Screen Size</td><td>$r1[5]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                  echo"<td>storage</td><td>$r1[6]</td>";;
                              echo"</tr>";
                              echo"<tr>";
                                 echo"<td>Front camera</td><td>$r1[7]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                 echo"<td>Rare camera</td><td>$r1[8]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                 echo"<td>Battery</td><td>$r1[9]</td>";
                              echo"</tr>";
                              echo"<tr>";
                                 echo"<td>Connectivity</td><td>$r1[10]</td>";
                              echo"</tr>";
                    echo"</table>";
                   
        ?>
                         </div>
          </div>
      </div>
      <?php include '../footer.php';?>
</body>
</html>
       
