<?php
session_start();
if(!isset($_SESSION['name']))
{
    header("location:alogin.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eShop.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row" style="background-color:grey;height:100px;padding-left:20px">
        <div class="col-sm-12">
            
     
       <?php
       
       include 'aheader.php';
       include 'menu.php';
       ?>
               </div>
    </div>
        <div class="row" style="background-color:lightcoral;height:600px">
            <div class="col-sm-6" style="padding-top: 200px">
                <a href="aproduct.php"style="color: black"><h2>For Adding Product</h2></a>
            
        </div>
            <div class="col-sm-6" style="padding-top: 200px">
              <a href="#" style="color:black"><h2>For Adding Product Description</h2></a>
            
            
        </div>
        </div>
        
    </div>
       <div class="row">
            <div class="col-sm-12">
                <?php
                $link= mysql_connect("localhost","root","");
                mysql_select_db("eshop");
                $result=mysql_query("select*from product_master");
                if(mysql_affected_rows()>0)
                {
                   echo"<table class='table table-stripped width=100%'>";
                    echo"<tr>";
                        echo"<th>Product ID</th><th>Name</th><th>Type</th><th>Price</th><th>Image</th><th>Add desc</th><th>Edit</th><th>Delete</th><th>View Desc</th>";
                        echo"</tr>";
                    while($r=mysql_fetch_array($result))
                    {
                    echo"<tr>";
                        echo"<td>$r[0]</td>";
                        echo"<td>$r[1]</td>";
                        echo"<td>$r[2]</td>";
                        echo"<td>$r[3]</td>";
                        echo"<td><img src='../$r[4]' width='30' height='50'/></td>";
                        echo"<td><a href='productdesc.php?pid=$r[0]'><input type='button' value='Add desc' class='form-control>'</a></td>";
                        echo"<td><a href='edit.php?pid=$r[0]'><input type='button' value='Edit' class='form-control>'</a></td>";
                        echo"<td><a href='delete.php?pid=$r[0]'><input type='button' value='Delete' class='form-control>'</a></td>";
                        echo"<td><a href='viewdesc.php?pid=$r[0]'><input type='button' value='View desc' class='form-control>'</a></td>";
                        
                      
                     echo"</tr>";
                    }
                    echo"</table>";
                }
                else
                     echo"No product available!!!";
                     ?>
                
                
            </div>
            
        </div>
       
           <?php include '../footer.php';?>
   
    </div>
    
</body>
</html>
