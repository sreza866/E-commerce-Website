<?php
  session_start();
  if(!isset($_SESSION['name']))
  {
      header("location:login.php");
  }
?>
<?php
    $msg="";
    $l="";
    $li="";
    if(isset($_GET['list']))
    {
        
     $l=$_GET['list'];
     $li=$_GET['user'];
   
    }
 if(isset($_POST['sub']))
 {
     $name=$_POST['name'];
     $phone=$_POST['phone'];
     $house=$_POST['house'];
     $street=$_POST['street'];
     $locality=$_POST['local'];
     $pin=$_POST['pin'];
     $state=$_POST['state'];
     $i= uniqid();
   $link=mysql_connect("localhost","root","");
    mysql_select_db("eshop");
      $qry="insert into place_order values('$name',$phone,'$house','$street','$locality',$pin,'$state','$li','$i','$l')";
      mysql_query($qry);
      if(mysql_affected_rows()>0)
      {
           $msg="<h5><font color='green'>Order Placed Successfully</font></h5>";
      }
      else {
               $msg="<h5><font color='red'>Error in placing order</font></h5>";
           }
           mysql_close($link);
      }
?>


<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title></title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
    <?php include 'header.php';?>
    <?php include 'usermenu.php';?>
    <form method="post">
        <div class="row" style='background-color:yellow' >
            
            <div class="col-sm-3"></div>
                
            <div class='col-sm-6' style='background-color:blanchedalmond'>
        <table class="table table-stripped">
            <tr>
                <td><label>Enter your full name</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='name' value=""></td>
            </tr>
             <tr>
                <td><label>Mobile no.</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='phone' value=""></td>
            </tr>
             <tr>
                <td><label>House no.</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='house' value=""></td>
            </tr>
             <tr>
                <td><label>Street</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='street' value=""></td>
            </tr>
             <tr>
                <td><label>locality</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='local' value=""></td>
            </tr>
             <tr>
                <td><label>Pin code</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='pin' value=""></td>
            </tr>
             <tr>
                <td><label>State</label></td>
            </tr>
            <tr>
                <td><input type='text' size="40" name='state' value=""></td>
            </tr>
           
            <tr>
                <td><input type='submit' name='sub' style="width:130px;height:50;margin-left:520px;background-color:green;color:palegoldenrod" value="Confirm"></td>
            </tr>
            <?php echo $msg;?>
            
            
            
            
            
        </table>
            </div>
             <div class="col-sm-3"></div>
            
    </div>
    </form>
     <?php include 'footer.php';?>
</body>
</html>
