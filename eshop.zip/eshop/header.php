﻿<div class="row" style="font-size:large;height:60px;background-color:lightgreen">
    <div class="col-sm-2"> <img src="eshop.jpg" style="height:60px;width:90px"/></div>
    <div class="col-sm-4" style="padding-top: 10px"> <label>search</label><input type='text' id='search' onkeyup='getproduct()' name='bar' style='margin-left: 10px;border-radius: 5px' size='40' placeholder="search for products" value=''/></div>
 
                
 <div class="col-sm-1" style="padding-top: 10px"> <a href="#">More</a></div>
  <?php
  $p=0;
  include_once 'db.php';
  $result=mysql_query("select * from product_master ");
  $r=mysql_fetch_array($result);
  if(isset($_COOKIE['num']))
  {
      $p=$_COOKIE['num'];
  }
 else {
     $p=0;
      
 }
  echo "<div class='col-sm-1' style='padding-top: 10px'> <a href='mycart.php?pid=$r[0]'>Cart($p)</a></div>";
 ?>
 <div class='col-sm-1' style='padding-top: 10px'><a href='login.php'>Login</a></div>
 <div class='col-sm-1' style='padding-top: 10px'><a href='logout.php'>Logout</a></div>

</div>
