<?php
 if(isset($_POST['btn_login']))
 {
     $uname=$_POST['txt_uname'];
     $pwd=$_POST['txt_pwd'];
     include_once './db.php';
     $qry="select * from signup where emailid='$uname' and password='$pwd' and role='client'";
     mysql_query($qry);
   
     if(mysql_affected_rows()>0)
     {
        $result= mysql_query("select * from signup where emailid='$uname'");
        $r=mysql_fetch_array($result);
         session_start();
         $_SESSION['name']=$r[0];
         $_SESSION['email']=$r[1];
         
         
         header("location:home.php");
         
     }
 else        
  {
   $msg="<strong><font color='red'>Invalid username or password</font></strong>" ;
  }
 }
?>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title></title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
    <body>
        
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <form method="post">
                        <h4> Login to <strong>eShop</strong></h4><br>
                            <label>Enter Email-ID</label>
                            <input type="text" name="txt_uname" class="form-control"/>
                             <label>Enter Password</label>
                             <input type="password" name="txt_pwd"class="form-control"/><br>
                                 <input type="submit" name="btn_login" value="login" class="btn btn-info"/> <span class="glyphicon glyphicon-user"></span>
                             </div>
                                 
                        
                    </form>
                </div>
            </div>
            
            
        
        
    </body>
</html>